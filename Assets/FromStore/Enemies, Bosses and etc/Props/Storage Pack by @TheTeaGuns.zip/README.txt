Thanks for downloading my low poly storage pack.

The pack includes 12 objects - 4 barrels, 2 crates, 3 chests, 1 keg, 1 barrel lid and 1 crate lid. Two different textures are included to give your items different looks.

Both .FBX and .OBJ files are included and all models use the same included textures.